//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//	___COPYRIGHT___
//

import UIKit
import RxSwift
import RxCocoa

extension UIViewController {
	func present___VARIABLE_productName___(animated: Bool) -> Observable<___VARIABLE_productName___Action> {
		let controller = createRaw()
		present(controller, animated: animated)

		// handle dismissal here.

		return controller.bind()
	}
}

extension UINavigationController {
	func push___VARIABLE_productName___(animated: Bool) -> Observable<___VARIABLE_productName___Action> {
		let controller = createRaw()
		pushViewController(controller, animated: animated)

		// handle popping here.

		return controller.bind()
	}
}

func create___VARIABLE_productName___() -> (UIViewController, Observable<___VARIABLE_productName___Action>) {
	let controller = createRaw()

	return (
		controller,
		controller.bind()
	)
}

enum ___VARIABLE_productName___Action {
}

private extension ___VARIABLE_productName___ViewController {
	func bind() -> Observable<___VARIABLE_productName___Action> {
		loadViewIfNeeded()
		// bind logic to the views here.

		// return action to communicate to parent view controller.
		return .never()
	}
}

private func createRaw() -> ___VARIABLE_productName___ViewController {
	let storyboard = UIStoryboard(name: "___VARIABLE_productName___", bundle: nil)
	return storyboard.instantiateInitialViewController() as! ___VARIABLE_productName___ViewController
}
