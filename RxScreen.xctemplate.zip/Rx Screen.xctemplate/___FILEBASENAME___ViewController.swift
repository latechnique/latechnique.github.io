//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//	___COPYRIGHT___
//

import UIKit
import RxSwift

final class ___VARIABLE_productName___ViewController: UIViewController {

	// view properties go here.
	
	let disposeBag = DisposeBag()
}
